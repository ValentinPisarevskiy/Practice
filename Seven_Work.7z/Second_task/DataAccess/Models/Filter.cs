﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public partial class Filter
    {
        public int IdFilter { get; set; }
        public int IdCategory { get; set; }
        public string FilterName { get; set; } = null!;
        public bool IsDeleted { get; set; }

        public virtual Category IdCategoryNavigation { get; set; } = null!;
    }
}
