﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Domain.Migrations
{
    public partial class MigratonName : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Category",
                columns: table => new
                {
                    ID_category = table.Column<int>(type: "int", nullable: false),
                    Category_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Category", x => x.ID_category);
                });

            migrationBuilder.CreateTable(
                name: "Delivery",
                columns: table => new
                {
                    Delivery_id = table.Column<int>(type: "int", nullable: false),
                    Delivery_type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Delivery", x => x.Delivery_id);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    Role_id = table.Column<int>(type: "int", nullable: false),
                    Role_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.Role_id);
                });

            migrationBuilder.CreateTable(
                name: "Status",
                columns: table => new
                {
                    Status_id = table.Column<int>(type: "int", nullable: false),
                    Status_type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Status", x => x.Status_id);
                });

            migrationBuilder.CreateTable(
                name: "Filters",
                columns: table => new
                {
                    ID_filter = table.Column<int>(type: "int", nullable: false),
                    ID_category = table.Column<int>(type: "int", nullable: false),
                    Filter_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Filters", x => x.ID_filter);
                    table.ForeignKey(
                        name: "FK_Filters_Category",
                        column: x => x.ID_category,
                        principalTable: "Category",
                        principalColumn: "ID_category",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ID_product = table.Column<int>(type: "int", nullable: false),
                    Product_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Product_description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Price = table.Column<decimal>(type: "decimal(7,2)", nullable: false),
                    ID_category = table.Column<int>(type: "int", nullable: true),
                    is_deleted = table.Column<bool>(type: "bit", nullable: true),
                    Warehouse_quantity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ID_product);
                    table.ForeignKey(
                        name: "FK_Products_Category",
                        column: x => x.ID_category,
                        principalTable: "Category",
                        principalColumn: "ID_category",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    ID_user = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Login = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Role_id = table.Column<int>(type: "int", nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.ID_user);
                    table.ForeignKey(
                        name: "FK_Users_Role",
                        column: x => x.Role_id,
                        principalTable: "Role",
                        principalColumn: "Role_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Filter_item",
                columns: table => new
                {
                    ID_product = table.Column<int>(type: "int", nullable: false),
                    ID_filter = table.Column<int>(type: "int", nullable: false),
                    Filter_value = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_Filter_item_Filters",
                        column: x => x.ID_filter,
                        principalTable: "Filters",
                        principalColumn: "ID_filter",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Filter_item_Products",
                        column: x => x.ID_product,
                        principalTable: "Products",
                        principalColumn: "ID_product");
                });

            migrationBuilder.CreateTable(
                name: "Cart",
                columns: table => new
                {
                    ID_user = table.Column<int>(type: "int", nullable: false),
                    ID_product = table.Column<int>(type: "int", nullable: false),
                    Quantity_product = table.Column<int>(type: "int", nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_Cart_Products",
                        column: x => x.ID_product,
                        principalTable: "Products",
                        principalColumn: "ID_product",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Cart_Users",
                        column: x => x.ID_user,
                        principalTable: "Users",
                        principalColumn: "ID_user",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    ID_order = table.Column<int>(type: "int", nullable: false),
                    ID_user = table.Column<int>(type: "int", nullable: false),
                    Delivery_id = table.Column<int>(type: "int", nullable: false),
                    status_id = table.Column<int>(type: "int", nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false),
                    Date_order = table.Column<DateTime>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.ID_order);
                    table.ForeignKey(
                        name: "FK_Orders_Delivery",
                        column: x => x.Delivery_id,
                        principalTable: "Delivery",
                        principalColumn: "Delivery_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Orders_Status",
                        column: x => x.status_id,
                        principalTable: "Status",
                        principalColumn: "Status_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Orders_Users",
                        column: x => x.ID_user,
                        principalTable: "Users",
                        principalColumn: "ID_user",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Order_item",
                columns: table => new
                {
                    ID_product = table.Column<int>(type: "int", nullable: false),
                    ID_order = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    is_deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_Order_item_Orders",
                        column: x => x.ID_order,
                        principalTable: "Orders",
                        principalColumn: "ID_order",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Order_item_Products",
                        column: x => x.ID_product,
                        principalTable: "Products",
                        principalColumn: "ID_product",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cart_ID_product",
                table: "Cart",
                column: "ID_product");

            migrationBuilder.CreateIndex(
                name: "IX_Cart_ID_user",
                table: "Cart",
                column: "ID_user");

            migrationBuilder.CreateIndex(
                name: "IX_Filter_item_ID_filter",
                table: "Filter_item",
                column: "ID_filter");

            migrationBuilder.CreateIndex(
                name: "IX_Filter_item_ID_product",
                table: "Filter_item",
                column: "ID_product");

            migrationBuilder.CreateIndex(
                name: "IX_Filters_ID_category",
                table: "Filters",
                column: "ID_category");

            migrationBuilder.CreateIndex(
                name: "IX_Order_item_ID_order",
                table: "Order_item",
                column: "ID_order");

            migrationBuilder.CreateIndex(
                name: "IX_Order_item_ID_product",
                table: "Order_item",
                column: "ID_product");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_Delivery_id",
                table: "Orders",
                column: "Delivery_id");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_ID_user",
                table: "Orders",
                column: "ID_user");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_status_id",
                table: "Orders",
                column: "status_id");

            migrationBuilder.CreateIndex(
                name: "IX_Products_ID_category",
                table: "Products",
                column: "ID_category");

            migrationBuilder.CreateIndex(
                name: "IX_Users_Role_id",
                table: "Users",
                column: "Role_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cart");

            migrationBuilder.DropTable(
                name: "Filter_item");

            migrationBuilder.DropTable(
                name: "Order_item");

            migrationBuilder.DropTable(
                name: "Filters");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Delivery");

            migrationBuilder.DropTable(
                name: "Status");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Category");

            migrationBuilder.DropTable(
                name: "Role");
        }
    }
}
