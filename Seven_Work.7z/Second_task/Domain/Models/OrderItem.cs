﻿using System;
using System.Collections.Generic;

namespace Domain.Models
{
    public partial class OrderItem
    {
        public int IdProduct { get; set; }
        public int IdOrder { get; set; }
        public int Quantity { get; set; }
        public bool IsDeleted { get; set; }

        public virtual Order IdOrderNavigation { get; set; } = null!;
        public virtual Product IdProductNavigation { get; set; } = null!;
    }
}
