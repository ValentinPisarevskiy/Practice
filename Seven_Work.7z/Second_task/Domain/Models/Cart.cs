﻿using System;
using System.Collections.Generic;

namespace Domain.Models
{
    public partial class Cart
    {
        public int IdUser { get; set; }
        public int IdProduct { get; set; }
        public int QuantityProduct { get; set; }
        public bool IsDeleted { get; set; }

        public virtual Product IdProductNavigation { get; set; } = null!;
        public virtual User IdUserNavigation { get; set; } = null!;
    }
}
