﻿using System;
using System.Collections.Generic;

namespace Domain.Models
{
    public partial class FilterItem
    {
        public int IdProduct { get; set; }
        public int IdFilter { get; set; }
        public string? FilterValue { get; set; }
        public bool IsDeleted { get; set; }

        public virtual Filter IdFilterNavigation { get; set; } = null!;
        public virtual Product IdProductNavigation { get; set; } = null!;
    }
}
