﻿using System;
using System.Collections.Generic;

namespace Domain.Models
{
    public partial class Order
    {
        public int IdUser { get; set; }
        public int IdOrder { get; set; }
        public int DeliveryId { get; set; }
        public int StatusId { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime DateOrder { get; set; }

        public virtual Delivery Delivery { get; set; } = null!;
        public virtual User IdUserNavigation { get; set; } = null!;
        public virtual Status Status { get; set; } = null!;
    }
}
