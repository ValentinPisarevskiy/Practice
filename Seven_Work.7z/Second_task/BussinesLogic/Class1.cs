﻿namespace BussinesLogic
{
    public class Class1
    {

    }
}