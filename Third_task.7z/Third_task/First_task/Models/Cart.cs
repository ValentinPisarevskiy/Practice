﻿using System;
using System.Collections.Generic;

namespace First_task.Models
{
    public partial class Cart
    {
        public int CartsId { get; set; }
        public int IdUser { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public bool IsDeleted { get; set; }

        public virtual User IdUserNavigation { get; set; } = null!;
        public virtual Product Product { get; set; } = null!;
    }
}
