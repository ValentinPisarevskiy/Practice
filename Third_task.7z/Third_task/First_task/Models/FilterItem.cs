﻿using System;
using System.Collections.Generic;

namespace First_task.Models
{
    public partial class FilterItem
    {
        public int FilterItemId { get; set; }
        public int ProductId { get; set; }
        public int FilterId { get; set; }
        public string? FilterValue { get; set; }
        public bool IsDeleted { get; set; }

        public virtual Filter Filter { get; set; } = null!;
        public virtual Product Product { get; set; } = null!;
    }
}
