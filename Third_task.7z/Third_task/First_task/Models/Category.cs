﻿using System;
using System.Collections.Generic;

namespace First_task.Models
{
    public partial class Category
    {
        public Category()
        {
            Filters = new HashSet<Filter>();
            Products = new HashSet<Product>();
        }

        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = null!;
        public bool IsDeleted { get; set; }

        public virtual ICollection<Filter> Filters { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
