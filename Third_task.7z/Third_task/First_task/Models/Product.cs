﻿using System;
using System.Collections.Generic;

namespace First_task.Models
{
    public partial class Product
    {
        public Product()
        {
            Carts = new HashSet<Cart>();
            FilterItems = new HashSet<FilterItem>();
            OrdersItems = new HashSet<OrdersItem>();
        }

        public int ProductId { get; set; }
        public string ProductName { get; set; } = null!;
        public string? ProductDescription { get; set; }
        public int WarehouseQuantity { get; set; }
        public int? Price { get; set; }
        public int? CategoryId { get; set; }
        public bool IsDeleted { get; set; }

        public virtual Category? Category { get; set; }
        public virtual ICollection<Cart> Carts { get; set; }
        public virtual ICollection<FilterItem> FilterItems { get; set; }
        public virtual ICollection<OrdersItem> OrdersItems { get; set; }
    }
}
