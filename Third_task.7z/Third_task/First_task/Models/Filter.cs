﻿using System;
using System.Collections.Generic;

namespace First_task.Models
{
    public partial class Filter
    {
        public Filter()
        {
            FilterItems = new HashSet<FilterItem>();
        }

        public int FilterId { get; set; }
        public int CategoryId { get; set; }
        public string FilterName { get; set; } = null!;
        public bool IsDeleted { get; set; }

        public virtual Category Category { get; set; } = null!;
        public virtual ICollection<FilterItem> FilterItems { get; set; }
    }
}
